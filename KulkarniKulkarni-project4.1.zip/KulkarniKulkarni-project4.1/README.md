1. Group members:
   Aarti Kulkarni (UFID: 80419396)
   Abhishek Kulkarni (UFID: 19819521)

2. What is working/Functionalities:
   •	Based on the number of users provided as input, client processes are created along with accounts
   •	A user can login or logout from the system
   •	Each client sends several tweets depending on the number provided as input
   •	A user can subscribe to any other user using the user-id
   •	A user can send the tweet to others using mentions. The tweets can include and hashtags or mention any other user.
   •	A user can retweet any tweet that he/she has received from his/her followers
   •	A user can search a tweet that has a specific hashtag or query a tweet that has mentioned a particular user
   •	A user can delete his/her account from the system. This deletes all the relevant data of the user


   Test-cases implemented:
   A. User test-cases:
   1. Creating a user
   2. Deleting a user

   B. Server test-cases:
   1. Account Creation
   2. Account Deletion
   3. Tweeting messages
   4. Subscribing to a user
   5. Hashtags
   6. Mentions


3. The program can be run by using the following commands:
   mix escript.build
   escript twitter <num_usr> <num_msg>

   For instance: escript twitter 50 5

   To run test-cases:
   mix test


























# MyProgram
**TODO: Add description**

## Installation

If [available in Hex](https://hex.pm/docs/publish), the package can be installed
by adding `my_program` to your list of dependencies in `mix.exs`:

```elixir
def deps do
  [
    {:my_program, "~> 0.1.0"}
  ]
end
```

Documentation can be generated with [ExDoc](https://github.com/elixir-lang/ex_doc)
and published on [HexDocs](https://hexdocs.pm). Once published, the docs can
be found at [https://hexdocs.pm/my_program](https://hexdocs.pm/my_program).































# Twitter

**TODO: Add description**

## Installation

If [available in Hex](https://hex.pm/docs/publish), the package can be installed
by adding `twitter` to your list of dependencies in `mix.exs`:

```elixir
def deps do
  [
    {:twitter, "~> 0.1.0"}
  ]
end
```

Documentation can be generated with [ExDoc](https://github.com/elixir-lang/ex_doc)
and published on [HexDocs](https://hexdocs.pm). Once published, the docs can
be found at [https://hexdocs.pm/twitter](https://hexdocs.pm/twitter).
