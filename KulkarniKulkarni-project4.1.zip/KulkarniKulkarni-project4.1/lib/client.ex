defmodule Client do
  require Logger
  use GenServer

  @alpha "abcdefghijklmnopqrtsuvwxyz"

  def init(init_arg) do
    {ownID, other, f_count, t_count, hashtagList, serverId, owner, hash_count} = init_arg
    {name, password} = Enum.at(other, ownID)
    other= List.delete(other, {name, password})
    state= %{:serverId => serverId, :userdatamap => other, :id => ownID, :list => other, :f_count => f_count, :t_count => t_count, :hashtagList => hashtagList, :owner => owner, :hash_count => hash_count, :name => name, :password =>password  }
    {:ok, state}
  end


  def random_string(length, answer) do
    if length > 0 do
      random = :rand.uniform(26) - 1
      answer = answer <> String.at(@alpha, random)
      random_string(length - 1, answer)
    else
      answer
    end
  end

  def random_tweet(length, line, tag, ppl) do
    if length > 0 do
      probability = :rand.uniform(100)
      line =
        if probability > 90 do
          tpos = :rand.uniform(Enum.count(ppl)) - 1
          {name, password} = Enum.at(ppl, tpos)
          line <> "@" <> name
        else
          line
        end

        line =
          if probability > 90 do
            tpos = :rand.uniform(Enum.count(tag)) - 1
            tag = Enum.at(tag, tpos)
            line <> "@" <> tag
          else
            line
          end

        word =random_string(1+ :rand.uniform(10), "")
        random_tweet(length - 1, line <> " " <> word, tag, ppl)
      else
        line
      end
    end

    def do_retweet(state) do
      {ret, data} = send_toserver(state.serverId, {:SubscribedTweet, state.name, state.password}, false)
      if(Enum.count(data) == 0) do
        false
      else
        data = {:Retweet, state.name, state.password, Enum.at(data, :rand.uniform(Enum.count(data))- 1)}
        {:ok, data} = send_toserver(state.serverId, data, false)
        Logger.info("successful retweet")
        true
    end
  end

  def all_tweet(state) do
    {ret, data} = send_toserver(state.serverId, {:SubscribedTweet, state.name, state.password}, false)
    Logger.info("total tweets (id: #{state.id}): #{inspect Enum.count(data)}")
  end

  def all_tag(state) do
    for tag <- state.hashtagList do
      {ret, data} = send_toserver(state.serverId, {:TweetUsingHashtag, tag}, false)
      Logger.info("total tweets (id: #{state.id}), tag: #{tag}: #{inspect Enum.count(data)}")
    end
  end

  def subscribe_random(state) do
    {name, _} = Enum.random(state.userdatamap)
    send_toserver(state.serverId, {:Subscribe, state.name, state.password, name}, false)
  end

  def all_mention(state) do
    {ret, data} = send_toserver(state.serverId, {:Mention, state.name, state.password}, false)
    Logger.info("total mention (id: #{state.id}): #{inspect Enum.count(data)}")

  end


  def begin(state, max_wait) do
    if(state.t_count > 0)  do
      probability = :rand.uniform(100)

      if probability < 40 do
        probability = :rand.uniform(100)
        change =
          if probability > 20 do
            words = 10 + :rand.uniform(20)

          tweet = random_tweet(words, "", state.hashtagList, state.userdatamap)
          send_toserver(state.serverId, {:TweetPost, state.name, state.password, tweet}, false)
          1
        else
          if(do_retweet(state)) do
            1
          else
            0
          end
        end


        state = %{state | :t_count => state.t_count - change}
        Process.sleep(:rand.uniform(max_wait))
        begin(state, max_wait)
      else
        probability = :rand.uniform(100)

        if probability > 60 do
          all_tweet(state)
        end

        if probability > 40 && probability < 60 do
          all_tag(state)
        end

        if probability <= 40 do
          all_mention(state)
        end

        if probability <= 15 do
          subscribe_random(state)
        end

        Process.sleep(:rand.uniform(max_wait))
        begin(state, max_wait)
      end
    else
      GenServer.call(state.owner, {:startcomplete})

      Process.sleep(:rand.uniform(max_wait))
      begin(state, max_wait)
    end
  end


  def send_toserver(serverId, data, print) do
    {ret, retData}= GenServer.call(serverId, data)
    if print == true do
      Logger.info("#{inspect {ret, retData, data}}")

    end
    if(ret == :redirect) do
      send_toserver(retData, data, print)
    else
      {ret, retData}
    end
  end

  def handle_call({:create_acct}, _from, state) do
    ret = send_toserver(state.serverId, {:RegisterUser, state.name, state.password}, false)
    ret = send_toserver(state.serverId, {:UserLogin, state.name, state. password}, false)
    {:reply, ret, state}
  end

  def handle_cast({:start, max_wait}, state) do
    pidbtc = spawn fn ->
      begin(state, max_wait)
    end
    {:noreply, state}
  end

  def handle_cast({:Notification, data}, state) do
  Logger.info("Notification Received: " <> data)
  {:noreply, state}
end
end
