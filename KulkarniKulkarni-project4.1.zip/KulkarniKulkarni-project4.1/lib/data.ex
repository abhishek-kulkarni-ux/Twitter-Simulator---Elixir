defmodule UserData do
  defstruct userid: "", password: "", tweet: [], subscribed: [], deleteUser: false, usermention: [], userPid: nil, subscribedby: []
end

defmodule UserServer do
  use GenServer
  require Logger


  @impl true
  def init(init_arg) do
    userTable = :ets.new(:userLookup, [:set, :protected])
    tweetTable = :ets.new(:tweetLookup, [:set, :protected])
    hash_table = :ets.new(:hashLookup, [:set, :protected])
    state =  %{:user_table => userTable , :tweet_table => tweetTable, :hash_table => hash_table,  :tweet_count => 0}
    {:ok,state}
  end




  def handle_call({:register_user, userdata}, _from, state) do
    isNew = :ets.insert_new(state.user_table, {userdata.userid, userdata})
    if isNew do
      {:reply, {:ok, "success"}, state}
    else
      {:reply, {:bad, "already exists"}, state}
    end
  end

  def handle_call({:delete_user, userid}, _from, state) do
    data = :ets.lookup(state.user_table, userid)
    if Enum.count(data) > 0 do
      :ets.delete(state.user_table, userid)
      {:reply, {:ok, "success"}, state}
    else
      {:reply, {:bad, "invalid id"}, state}
    end
  end

  def handle_call({:getuser_id, userid}, _from, state) do
    data = :ets.lookup(state.user_table, userid)
    if Enum.count(data) > 0 do
      {_id, user} = Enum.at(data, 0)
      {:reply, {:ok, user}, state}
    else
      {:reply, {:bad, "invalid user id"}, state}
    end
  end

  def handle_call({:Tweet, tweet}, _from, state) do
    tweetId = state.tweet_count
    state= %{state | :tweet_count => tweetId + 1}
    :ets.insert_new(state.tweet_table, {tweetId, tweet})
    {:reply, {:ok, tweetId}, state}
  end

  def handle_call({:get_tweet, tweetId}, _from, state) do
    [{tweetId, tweet}] = :ets.lookup(state.tweet_table, tweetId)
    {:reply, {:ok, tweet} , state}
  end

  def handle_call({:update_user,user} , _from, state) do
    data = :ets.lookup(state.user_table, user.userid)
    if Enum.count(data) > 0 do
      :ets.insert(state.user_table, {user.userid, user})
      {:reply, {:ok, "success"}, state}
    else
      {:reply, {:bad, "invalid id"}, state}
    end
  end

  def handle_call({:add_hashtag, hash,tweetServer, tweetId}, _from, state) do
    # IO.puts("Insert hash #{hash}")
    data =:ets.lookup(state.hash_table, hash)
    if Enum.count(data) > 0 do
      {hash, list} = Enum.at(data, 0)
      :ets.insert(state.hash_table, {hash, list ++ [{tweetServer, tweetId}]})
    else
      :ets.insert_new(state.hash_table, {hash, [{tweetServer, tweetId}]})
    end
    {:reply, {:ok, "success"}, state}
  end

  def handle_call({:get_hashtag, hashtag}, _from, state) do
    data = :ets.lookup(state.hash_table, hashtag)
    # IO.inspect(data)
    if Enum.count(data) > 0 do
      {hash, list} = Enum.at(data, 0)
      {:reply, {:ok, list}, state}
    else
      {:reply, {:ok, []}, state}
    end
  end

  def handle_call({:usermention, user_name, tweetServer, tweetId}, _from, state) do
    data = :ets.lookup(state.user_table, user_name)
    if Enum.count(data) > 0 do
      {_name, user} = Enum.at(data, 0)
      if user.deleteUser == false do
        update_info = %UserData{userid: user.userid, password: user.password, tweet: user.tweet, subscribed: user.subscribed, deleteUser: user.deleteUser, usermention: user.usermention++[{tweetServer, tweetId}],  userPid: user.userPid, subscribedby: user.subscribedby}
        :ets.insert(state.user_table, {user_name, update_info})
      end
    end
    {:reply, {:ok, "success"}, state}
  end

  def handle_call({:logindetail, userid, userPid}, _from, state) do
    data = :ets.lookup(state.user_table, userid)
    if Enum.count(data) > 0 do
      {_id, user} = Enum.at(data, 0)
      update_info= %UserData{userid: user.userid, password: user.password, tweet: user.tweet, subscribed: user.subscribed, deleteUser: user.deleteUser, usermention: user.usermention, userPid: userPid, subscribedby: user.subscribedby}
      :ets.insert(state.user_table, {userid, update_info})
    #  IO.inspect(update_info)
      {:reply, {:ok, "success"}, state}
    else
      {:reply, {:bad, "invalid id"}, state}
    end
  end


  def handle_call({:logoutdetail, userid}, _from, state) do
    data = :ets.lookup(state.user_table, userid)
    if Enum.count(data) > 0 do
      {_id, user} = Enum.at(data, 0)
      update_info = %UserData{userid: user.userid, password: user.password, tweet: user.tweet, subscribed: user.subscribed, deleteUser: user.deleteUser, usermention: user.usermention, userPid: nil, subscribedby: user.subscribedby}
      :ets.insert(state.user_table, {userid, update_info})
      {:reply, {:ok, "success"}, state}
    else
      {:reply, {:bad, "invalid"}, state}
    end
  end

end
