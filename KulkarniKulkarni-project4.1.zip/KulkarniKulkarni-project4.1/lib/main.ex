defmodule Main do
  require Logger

  def wait(serverId) do
    if GenServer.call(serverId, {:done}) == false do
      Process.sleep(500)
      wait(serverId)
    end
  end

  def main(args \\ []) do
    [n_user, n_tweet] = args
    {n_user, _} = Integer.parse(n_user)
    {n_tweet, _} = Integer.parse(n_tweet)
    {:ok, serverId} = GenServer.start(Newmain, {n_user, n_tweet})
    GenServer.cast(serverId, {:start})
    wait(serverId)
    Process.sleep(500)
  end
end

defmodule Newmain do
  use GenServer
  require Logger

  @alpha "abcdefghijklmnopqrstuvwxyz"
  @follow_percent 0.30
  @hashtag_listsize 2
  @max_hashcount 10
  @max_wait 200


  def init(init_arg) do
    {n_user, n_tweet} = init_arg
    state = %{:nsep => n_user, :numuser => n_user, :numtweet => n_tweet}
    {:ok, state}
  end

  def random_string(length, answer) do
    if length > 0 do
      random = :rand.uniform(26) - 1
      answer = answer <> String.at(@alpha, random)
      random_string(length - 1, answer)
    else
      answer
    end
  end


  def gethashlist(count, list) do
    if count>0 do
      hashlength = :rand.uniform(4)
      hash = "#" <> random_string(5+hashlength, "")
      if(Enum.find_index(list, fn(hashvalue) -> hashvalue ==  hash end )== nil)  do
        gethashlist(count - 1 , list ++ [hash])
      else
        gethashlist(count, list)
      end
    else
      list
    end
  end

  def rand_cred(count, list) do
    if(count == 0) do
      list
    else
      newlen = 4 + :rand.uniform(10)
      new_name = random_string(newlen, "")
      pswdlen = 8 + :rand.uniform(4)
      password = random_string(pswdlen, "")
      if (Enum.find_index(list, fn({username, _password}) -> username == new_name end)) == nil do
        rand_cred(count - 1, list ++ [{new_name, password}])
      else
        IO.puts("got")
        rand_cred(count, list)
      end
    end
  end

  def create_client(count, serverId, userlist, clientlist, hashtagList,numtweet ) do
    if(count > 0 ) do
      f_count = Enum.count(userlist) * @follow_percent
      data = {count - 1, userlist, f_count, numtweet, hashtagList, serverId, self(), @max_hashcount}
      {:ok, clientPid} = GenServer.start(Client, data)
      GenServer.call(clientPid, {:create_acct})
      create_client(count - 1, serverId, userlist, clientlist ++ [clientPid], hashtagList, numtweet)
    else
      clientlist
    end
  end


  def clientstart(clientlist, position) do
    if position < Enum.count(clientlist) do
      GenServer.cast(Enum.at(clientlist, position), {:start, @max_wait})
      clientstart(clientlist, position + 1)

    end
  end

  def handle_call({:startcomplete}, _from, state) do
    state = %{state | :nsep => state.nsep - 1}
    {:reply, :ok, state}
  end


  def handle_call({:done}, _from, state) do
    if(state.nsep > 0) do
      {:reply, false, state}
    else
      {:reply, true, state}
    end
  end

  def handle_cast({:start}, state) do
    credlist = rand_cred(state.numuser, [])
    {:ok, serverId} = GenServer.start(Twitter, %{})
    hashlist = gethashlist(@hashtag_listsize, [])
    clientlist = create_client(state.numuser, serverId, credlist, [], hashlist, state.numtweet)
    clientstart(clientlist, 0)
  #  IO.inspect(clientlist)
    {:noreply, state}
  end

end
