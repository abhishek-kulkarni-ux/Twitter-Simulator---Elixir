defmodule Server do
  use GenServer
  require Logger

  def init(init_arg) do
    {:ok, init_arg}
  end

  def start(initstate) do
    GenServer.start(__MODULE__, initstate, [])
  end 

end
