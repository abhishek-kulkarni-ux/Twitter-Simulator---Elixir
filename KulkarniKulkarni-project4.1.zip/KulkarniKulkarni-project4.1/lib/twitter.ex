defmodule Twitter do
  use GenServer
  require Logger

  @impl true

  def init(_init_arg) do
    db_list =
      for _i <- 1..27   do
        {:ok,pid} = GenServer.start(UserServer, %{})
        pid
      end

      number_of_processors = 512

      data_server_list =
        for _i <- 1..number_of_processors do
          {:ok, pid} = GenServer.start(TwitterServer, db_list)
          pid
        end

        state=%{:data_shards => db_list, :data_shards_count =>27, :processor => data_server_list, :processor_cnt => number_of_processors, :last_server => 0}
        {:ok, state}
      end

      def redirect_data(state) do
        next_position = state.last_server
        state = %{state | :last_server => rem(state.last_server + 1, state.processor_cnt )}
        next_pid = Enum.at(state.processor, next_position)
        {:reply, {:redirect, next_pid}, state}
      end

      def handle_call({:RegisterUser, _name, _password}, _from, state) do
        redirect_data(state)
      end

      def handle_call({:UserLogin,  _name, _password}, _from, state) do
        redirect_data(state)
      end

      def handle_call({:UserLogout,  _name, _password}, _from, state) do
        redirect_data(state)
      end

      def handle_call({:TweetPost, _name, _password, _tweet}, _from, state) do
        redirect_data(state)
      end

      def handle_call({:Subscribe, _name, _password, _username}, _from, state) do
        redirect_data(state)
      end

      def handle_call({:DeleteUser, name, password}, _from, state) do
        redirect_data(state)
      end

      def handle_call({:SubscribedTweet, name, password}, _from, state) do
        redirect_data(state)
      end

      def handle_call({:TweetUsingHashtag, hashtag}, _from, state) do
        redirect_data(state)
      end

      def handle_call({:Mention, user_name, password}, _from, state) do
        redirect_data(state)
      end

      def handle_call({:Logout, _name, _password}, _from, state) do
        redirect_data(state)
      end

      def handle_call({:Retweet, _name, _password, _old_data}, _from, state) do
        redirect_data(state)
      end
    end
