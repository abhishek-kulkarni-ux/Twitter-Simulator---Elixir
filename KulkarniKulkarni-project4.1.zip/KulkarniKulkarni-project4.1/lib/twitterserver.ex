defmodule TwitterServer do
  use GenServer
  require Logger

  def flatten([]), do: []
  def flatten([h|t]), do: flatten(h) ++ flatten(t)
  def flatten(h), do: [h]

  def trim(data) do
    String.trim(data)
  end

  def post(hashtag, mentions, state, tweetServer, tweetId) do
    for tag <- hashtag do
      # IO.inspect("Post #{tag}")
      tag= convertToLower(tag)
      {serverPid, position} = getString(String.at(tag, 1), state)
      GenServer.call(serverPid, {:add_hashtag, tag, tweetServer, tweetId})
    end

    for user_mentioned <- mentions do
      user_mentioned = convertToLower(user_mentioned)
      {serverPid, position}= getString(String.slice(user_mentioned, 1..-1), state)
      GenServer.call(serverPid, {:usermention, String.slice(user_mentioned, 1..-1), tweetServer, tweetId})
    end
  end

  def get(tweet) do
    regex = ~r/\#\w+/
    tag = List.flatten(Regex.scan(regex, tweet))
    regex = ~r/\@\w+/
    mentions = List.flatten(Regex.scan(regex, tweet))
    {Enum.uniq(tag), Enum.uniq(mentions)}
  end

  def validate(name, password, user_obj) do
    if(name == user_obj.userid && password == user_obj.password && user_obj.deleteUser == false) do
      true
    else
      false
    end
  end

  def convertToLower(data) do
    String.downcase(data)
  end

  def string_notempty(check_str) do
    check_str = String.trim(check_str)
    String.length(check_str) > 0
  end

  def validate_notempty(data,label) do
    if string_notempty(data) do
      {:ok, "success"}
    else
      {:bad, label <> " empty"}
    end
  end

  def validate_login(name, password) do
    {valid, error} =validate_notempty(name, "id")

    if valid == :ok do

      if String.contains?(name, " ") do
        {:bad, "no spaces "}
      else
        if valid == :ok do
          validate_notempty(password, "password")
        else
          {valid, error}
        end
      end
    else
      {valid, error}
    end
  end

  def getString(word, state) do
    position = hd(String.to_charlist(String.at(word, 0))) - hd('a')
    if(position >= 0 && position <= 25) do
      {Enum.at(state.userdatamap, position), position}
    else
      {Enum.at(state.userdatamap, 26),26}
    end
  end

  def init(init_arg) do
    state = %{:userdatamap => init_arg}
    {:ok, state}
  end

  def handle_call({:RegisterUser, name, password}, _from, state) do
    name = trim(convertToLower(name))

    {ret, reason} = validate_login(name, password)

    if ret == :ok do
      {serverPid, _} = getString(name, state)
      newuser = %UserData{userid: name, password: password, tweet: [], subscribed: [], deleteUser: false, usermention: [], userPid: nil, subscribedby: []}
      {ret, reason} = GenServer.call(serverPid, {:register_user, newuser})
      {:reply, {ret, reason}, state}
    else
      {:reply, {ret, reason}, state}
    end
  end

  def handle_call({:UserLogin, name, password}, from, state) do
    name = trim(convertToLower(name))
    if string_notempty(name) do
      {serverPid, _} = getString(name, state)
      {res, user} = GenServer.call(serverPid, {:getuser_id, name})

      if res == :ok && user.deleteUser == false do
        if(validate(name, password, user)) do
          {pid, _} = from
          {:reply, GenServer.call(serverPid, {:logindetail, name, pid }), state}
        else
          {:reply, {:bad, "invalid"}, state}
        end
      else
        {:reply, {:bad, "invalid"}, state}
      end
    else
      {:reply, {:bad, "inalid"}, state}
    end
  end


  def handle_call({:UserLogout, name, password}, _from, state) do
    name = convertToLower(trim(name))
    if string_notempty(name) do
      {serverPid, _} = getString(name, state)
      {res, user} = GenServer.call(serverPid, {:getuser_id, name})

      if res == :ok && user.deleteUser == false do
        if(validate(name, password, user)) do
          {:reply, GenServer.call(serverPid, {:logindetail, name, nil}), state}
        else
          {:reply, {:bad, "invalid"}, state}
        end
      else
        {:reply, {:bad, "invalid"}, state}
      end
    else
      {:reply, {:bad, "id is empty"}, state}
    end
  end

  def handle_call({:TweetPost, name, password, tweet}, _from, state) do
    tweet = trim(tweet)
    if string_notempty(tweet) && string_notempty(name) do
      {serverPid, _} = getString(name,state)
      {res, user} = GenServer.call(serverPid, {:getuser_id, name})
      if res == :ok && (validate(name, password, user)) do
        {tweet_serverpid, getString_pos} = getString(convertToLower(tweet), state)
        {:ok, tweetId} = GenServer.call(tweet_serverpid, {:Tweet, {name, DateTime.utc_now(), tweet}})
        {hashtag, mentions} = get(tweet)
        post(hashtag, mentions, state, getString_pos, tweetId)

    #    IO.inspect(user.subscribedby)
        for subs <- user.subscribedby do
          {subserverPid, _} = getString(subs,state)
          {res, subuser} = GenServer.call(subserverPid, {:getuser_id, subs})
      #    IO.inspect(subuser)
          if(subuser.deleteUser == false && subuser.userPid != nil) do
            GenServer.cast(subuser.userPid, {:Notification, "new tweet posted by" <> name <> "tweet:" <> tweet})
          end
        end

        update_info = %UserData{userid: user.userid, password: user.password, tweet: user.tweet ++ [{getString_pos, tweetId}], subscribed: user.subscribed, userPid: user.userPid, deleteUser: user.deleteUser, usermention: user.usermention, subscribedby: user.subscribedby}
        {:reply, GenServer.call(serverPid, {:update_user, update_info}), state}
      else
        {:reply, {:bad, "invalid"}, state}
      end
    else
      {:reply,{:bad,"tweet empty"}, state}
    end
  end

  def handle_call({:DeleteUser, name, password}, _from, state) do
    name = convertToLower(trim(name))
    if string_notempty(name) do
      {serverPid, _} = getString(name, state)
      {res, user} = GenServer.call(serverPid, {:getuser_id, name})
      if res == :ok && user.deleteUser == false do
        if(validate(name, password, user )) do
          update_info= %UserData{userid: user.userid, password: user.password, tweet: user.tweet, subscribed: user.subscribed, deleteUser: true, usermention: user.usermention, userPid: nil,subscribedby: user.subscribedby}
          GenServer.call(serverPid, {:update_user, update_info})
          {:reply, {:ok, "success"},state}
        else
          {:reply, {:bad, "invalid id"}, state}

        end
      else
        {:reply, {:bad,"invalid"}, state}
      end
    else
      {:reply, {:bad, "id empty"}, state}
    end
  end

  def handle_call({:SubscribedTweet, name, password}, _from, state) do
    name= convertToLower(trim(name))
    if string_notempty(name) do
      {serverPid, _} = getString(name, state)
      {res, user} = GenServer.call(serverPid, {:getuser_id, name})
      if res == :ok && user.deleteUser == false do
        if(validate(name, password, user)) do
          tweet =
            for subUser <- user.subscribed do
              {subserverPid, _} = getString(subUser, state)
              {subRes, subuserObj} = GenServer.call(subserverPid, {:getuser_id, subUser})
              if subuserObj.deleteUser == false do
                data =
                for {tweetServer, tweetId}<-subuserObj.tweet do
                  {:ok, tweet} = GenServer.call(Enum.at(state.userdatamap, tweetServer), {:get_tweet, tweetId})
                  tweet
                end
              else
                []
              end
            end

            returnVal= flatten(tweet) |> Enum.sort_by(&(elem(&1, 1)))
            {:reply, {:ok, returnVal}, state}
          else
            {:reply, {:bad, "invalid"}, state}
          end
        else
          {:reply, {:bad, "invalid"}, state}
        end
      else
        {:reply, {:bad, "id is empty"}, state}
      end
    end

@impl true
def handle_call({:Subscribe, name, password, username}, _from, state) do
  username =convertToLower(trim(username))
  if string_notempty(username) do
    {serverPid, _} = getString(name, state)
    {res, user} = GenServer.call(serverPid, {:getuser_id, name})
    {subserverPid, _} = getString(username, state)
    {subRes, subUser} = GenServer.call(subserverPid, {:getuser_id, username})
    if subRes == :ok && subUser.deleteUser == false do
      if res == :ok do
        if(validate(name, password, user)) do
          if !(Enum.member?(user.subscribed, username)) do
            update_info = %UserData{userid: subUser.userid, password: subUser.password, tweet: subUser.tweet, subscribed: subUser.subscribed,subscribedby: subUser.subscribedby++[name], userPid: subUser.userPid, deleteUser: subUser.deleteUser, usermention: subUser.usermention}
            GenServer.call(subserverPid, {:update_user, update_info})
            update_info = %UserData{userid: user.userid, password: user.password, tweet: user.tweet, subscribed: user.subscribed ++  [username],subscribedby: user.subscribedby,userPid: user.userPid, deleteUser: user.deleteUser, usermention: user.usermention}
            {:reply, GenServer.call(serverPid, {:update_user, update_info}), state}
          else
            {:reply, {:bad, "subscription exists"}, state}
          end
        else
          {:reply, {:bad, "invalida aa"}, state}
        end
      else
        {:reply, {:bad, "invalid"}, state}
      end
    else
      {:reply, {:bad, "no account"}, state}
    end
  else
    {:reply, {:bad, "can't be empty"}, state}
  end
end

def handle_call({:TweetUsingHashtag, hashtag}, _from, state) do
  hashtag =convertToLower(trim(hashtag))
  if(string_notempty(hashtag)) do
    if(String.at(hashtag, 0) == "#") do
      {serverPid, position}= getString(String.at(hashtag, 1), state)
      {:ok, list} = GenServer.call(serverPid, {:get_hashtag, hashtag})
      # IO.inspect(list)
      tweet =
        for {getString_pos, tweetId} <- list do
          {:ok, tweet} = GenServer.call(Enum.at(state.userdatamap, getString_pos), {:get_tweet, tweetId})
          tweet
        end
        returnVal = flatten(tweet) |> Enum.sort_by(&(elem(&1,1)))
        {:reply, {:ok, returnVal}, state}
      else
        {:reply, {:bad, "hash missing"}, state}
      end
    else
      {:reply, {:bad, "cannot be empty"}, state}
    end
  end

def handle_call({:Mention, name, password}, _from, state) do
  {serverPid, _}= getString(name, state)
  {res, user} = GenServer.call(serverPid, {:getuser_id, name})
  if res == :ok && (validate(name, password, user)) do
    tweet =
      for {getString_pos, tweetId} <- user.usermention do
        {:ok, tweet} = GenServer.call(Enum.at(state.userdatamap, getString_pos), {:get_tweet, tweetId})
        tweet
      end
      returnVal = flatten(tweet) |> Enum.sort_by(&(elem(&1,1)))
      {:reply, {:ok, returnVal}, state}
    else
      {:reply, {:bad, "invalid"},state}
    end
  end


  def handle_call({:Retweet, name, password, old_data}, _from, state) do
    {_, _, tweet} = old_data
    tweet = trim(tweet)
    if string_notempty(tweet) && string_notempty(name) do
      {serverPid, _} = getString(name, state)
      {res, user} = GenServer.call(serverPid, {:getuser_id, name})
      if res == :ok && (validate(name, password, user)) do
        tweet = "retweet" <> tweet
        {tweet_serverpid, getString_pos} = getString(convertToLower(tweet) , state)
        {:ok, tweetId} = GenServer.call(tweet_serverpid, {:Tweet, {:name, DateTime.utc_now(), tweet}})
        {hashtag, mentions} = get(tweet)
        post(hashtag, mentions, state, getString_pos, tweetId)
        update_info = %UserData{userid: user.userid, password: user.password, tweet: user.tweet ++ [{getString_pos, tweetId}], subscribed: user.subscribed, userPid: user.userPid, deleteUser:  user.deleteUser, usermention: user.usermention, subscribedby: user.subscribedby}
        {:reply, GenServer.call(serverPid, {:update_user, update_info}), state}

    else
      {:reply, {:bad, "invalid"}, state}
    end
  else
    {:reply, {:bad, "tweet cannot be empty"}, state}
  end
end
end
