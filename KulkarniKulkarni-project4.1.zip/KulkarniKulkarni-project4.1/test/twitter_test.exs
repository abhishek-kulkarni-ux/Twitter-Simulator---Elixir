defmodule TwitterTest do
  use ExUnit.Case
  doctest Twitter
  require Logger

  test "account creation" do
    {:ok, serverPid} = GenServer.start(Twitter, %{})
    {response, data} = GenServer.call(serverPid, {:RegisterUser, "abc", "123"})

    assert response ==:redirect

    {ret, reason} = GenServer.call(data, {:RegisterUser, "abc", "123"})
    assert ret == :ok
    assert reason == "success"

    {ret, reason} = GenServer.call(data, {:RegisterUser, "abc", "123"})
    assert ret == :bad
    assert reason == "already exists"

    {ret, reason} = GenServer.call(data, {:RegisterUser, "abc", "123"})
    assert ret == :bad
    assert reason == "already exists"

    {ret, reason} = GenServer.call(data, {:RegisterUser, "", "123"})
    assert ret == :bad
    assert reason == "id empty"

    {ret, reason} = GenServer.call(data, {:RegisterUser, "  ", "123"})
    assert ret == :bad
    assert reason == "id empty"

    {ret, reason} = GenServer.call(data, {:RegisterUser, "  ", "  "})
    assert ret == :bad
    assert reason == "id empty"

    {ret, reason} = GenServer.call(data, {:RegisterUser, "abc", " "})
    assert ret == :bad
    assert reason == "password empty"

    {ret, reason} = GenServer.call(data, {:RegisterUser, "abc", ""})
    assert ret == :bad
    assert reason == "password empty"

  end

  test "delete user" do
    {:ok, serverPid} = GenServer.start(Twitter, %{})

    {response, data} = GenServer.call(serverPid, {:RegisterUser, "abc", "123"})
    assert response == :redirect
    {ret, reason} = GenServer.call(data , {:RegisterUser, "abc", "123"})
    assert ret == :ok
    assert reason == "success";

    {response, data} = GenServer.call(serverPid, {:DeleteUser, "abc", "123"})
    assert response == :redirect
    {ret, reason} = GenServer.call(data, {:DeleteUser, "abc", "123"})
    assert ret == :ok
    assert reason == "success"
    {response, data} = GenServer.call(serverPid, {:DeleteUser, "abc", "123"})
    assert response == :redirect
    {ret, reason} = GenServer.call(data, {:DeleteUser, "abc", "123"})
    assert ret == :bad
    assert reason == "invalid"
  end

  test "tweet" do
    {:ok, serverPid} = GenServer.start(Twitter, %{})

    {response, data} = GenServer.call(serverPid, {:RegisterUser, "abc", "123"})
    assert response == :redirect

    {ret, reason} = GenServer.call(data, {:RegisterUser, "abc", "123"})
    assert ret == :ok
    assert reason == "success"

    {response, data} = GenServer.call(serverPid, {:TweetPost, "abc", "123", "first tweet"})
    assert response == :redirect

    {ret, reason} = GenServer.call(data, {:TweetPost, "ac", "123", "first tweet"})
    assert ret == :bad
    assert reason == "invalid"

    {response, data} = GenServer.call(serverPid, {:TweetPost, "abc", "123", "first tweet"})
    assert response == :redirect
    {ret, reason} = GenServer.call(data, {:TweetPost, "abc", "12", "first tweet"})
    assert ret == :bad
    assert reason == "invalid"

    {response, data} = GenServer.call(serverPid, {:TweetPost, "abc", "123", "first tweet"})
    assert response == :redirect
    {ret, reason} = GenServer.call(data, {:TweetPost, "abc", "123", "first tweet"})
    assert ret == :ok
    assert reason == "success"

    {response, data} = GenServer.call(serverPid, {:TweetPost, "abc", "123", "first tweet"})
    assert response == :redirect
    {ret, reason} = GenServer.call(data, {:TweetPost, "abc", "123", " "})
    assert ret == :bad
    assert reason == "tweet empty"

    {response, data} = GenServer.call(serverPid, {:TweetPost, "abc", "123", "first tweet"})
    assert response == :redirect
    {ret, reason} = GenServer.call(data, {:TweetPost, "abc", "123", ""})
    assert ret == :bad
    assert reason == "tweet empty"
  end


  test " Subscribe" do
    {:ok, serverPid} = GenServer.start(Twitter, %{})
    {response, data} = GenServer.call(serverPid, {:RegisterUser, "abc", "123"})
    assert response == :redirect
    {ret, reason} = GenServer.call(data, {:RegisterUser, "abc", "123"})
    assert ret == :ok
    assert reason == "success"



   {response, data} = GenServer.call(serverPid, {:RegisterUser, "xyz", "421"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:RegisterUser, "xyz", "421"})
   assert ret == :ok
   assert reason == "success"

   {response, data} = GenServer.call(serverPid, {:RegisterUser, "pqr", "112"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:RegisterUser, "pqr", "112"})
   assert ret == :ok
   assert reason == "success"

   {response, data} = GenServer.call(serverPid, {:Subscribe, "xyz", "421", "112"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:Subscribe, "xyz", "421", "112"})
   assert ret == :bad
   assert reason == "no account"

   {response, data} = GenServer.call(serverPid, {:Subscribe, "xyz", "421", "112"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:Subscribe, "xyz", "41", "112"})
   assert ret == :bad
   assert reason == "no account"

   {response, data} = GenServer.call(serverPid, {:Subscribe, "xyz", "421", "pqr"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:Subscribe, "xyz", "421", "ass"})
   assert ret == :bad
   assert reason == "no account"

   {response, data} = GenServer.call(serverPid, {:Subscribe, "xyz", "421", "pqr"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:Subscribe, "xyz", "421", " "})
   assert ret == :bad
   assert reason == "can't be empty"

   {response, data} = GenServer.call(serverPid, {:Subscribe, "xyz", "421", "pqr"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:Subscribe, "xyz", "421", ""})
   assert ret == :bad
   assert reason == "can't be empty"

   {response, data} = GenServer.call(serverPid, {:Subscribe, "xyz", "421", "pqr"})
   assert response ==:redirect
   {ret, reason} = GenServer.call(data, {:Subscribe, "xyz", "421", "pqr"})
   IO.inspect(reason)
   assert ret == :ok
   assert reason == "success"

   {response, data} = GenServer.call(serverPid, {:Subscribe, "xyz", "421", "pqr"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:Subscribe, "xyz", "421", "pqr"})
   assert ret == :bad
   assert reason == "subscription exists"

   {response, data} = GenServer.call(serverPid, {:Subscribe, "xyz", "421", "pqrs"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:Subscribe, "xyz", "421", "pqrs"})
   assert ret == :bad
   assert reason == "no account"

   {response, data} = GenServer.call(serverPid, {:RegisterUser, "qwe", "rty"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:RegisterUser, "qwe", "rty"})
   assert ret == :ok
   assert reason == "success"

   {response, data} = GenServer.call(serverPid, {:DeleteUser, "qwe", "rty"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:DeleteUser, "qwe", "rty"})
   assert ret == :ok
   assert reason == "success"

   {response, data} = GenServer.call(serverPid, {:Subscribe, "abc", "123", "qwe"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:Subscribe, "abc", "123", "qwe"})
   assert ret == :bad
   assert reason == "no account"

   {response, data} = GenServer.call(serverPid, {:TweetPost, "pqr", "112", " first tweet."})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:TweetPost, "pqr", "112", "pqr first tweet."})
   assert ret == :ok
   assert reason == "success"

   {response, data} = GenServer.call(serverPid, {:SubscribedTweet, "abc", "123"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:SubscribedTweet, "abc", "123"})
   assert ret == :ok
 end

 test "Hashtag" do
   {:ok, serverPid} = GenServer.start(Twitter, %{})

   {response, data} = GenServer.call(serverPid, {:RegisterUser, "abc", "123"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:RegisterUser, "abc", "123"})
   assert ret == :ok
   assert reason == "success"

   {response, data} = GenServer.call(serverPid, {:RegisterUser, "pqr", "112"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:RegisterUser, "pqr", "112"})
   assert ret == :ok
   assert reason == "success"

   {response, data} = GenServer.call(serverPid, {:TweetPost, "abc", "123", "first tweet"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:TweetPost, "abc", "123", "first tweet #awesome"})
   assert ret == :ok
   assert reason == "success"

   {response, data} = GenServer.call(serverPid, {:TweetUsingHashtag, "#awesome"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:TweetUsingHashtag, "#awesome"})

   assert ret == :ok
   assert Enum.count(reason) == 1
   [{posted_by, _a, tweet}] = reason
   assert posted_by == "abc"
   assert tweet == "first tweet #awesome"

   {response, data} = GenServer.call(serverPid, {:TweetUsingHashtag, ""})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:TweetUsingHashtag, ""})
   assert ret == :bad
   assert reason == "cannot be empty"

   {response, data} = GenServer.call(serverPid, {:TweetUsingHashtag, ""})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:TweetUsingHashtag, ""})
   assert ret == :bad
   assert reason == "cannot be empty"


   {response, data} = GenServer.call(serverPid, {:TweetPost, "pqr", "112", "i love #coffee #awesome."})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:TweetPost, "pqr", "112", "i love #coffee #awesome."})
   assert ret == :ok
   assert reason == "success"

   {response, data} = GenServer.call(serverPid, {:TweetUsingHashtag, "#awesome"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:TweetUsingHashtag, "#awesome"})
   assert ret == :ok
   #IO.puts("AArti #{inspect reason}")
   assert Enum.count(reason) == 2
   [{posted_by, _a, tweet}, {posted_by_2, _b, tweet_2}] = reason
   assert posted_by == "abc"
   assert tweet == "first tweet #awesome"
   assert posted_by_2 == "pqr"
   assert tweet_2 == "i love #coffee #awesome."


   {response, data} = GenServer.call(serverPid, {:TweetUsingHashtag, "#coffee"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:TweetUsingHashtag, "#coffee"})
   assert ret == :ok
   assert Enum.count(reason) == 1
   [{posted_by_2, _b, tweet_2}] = reason
   assert posted_by_2 == "pqr"
   assert tweet_2 == "i love #coffee #awesome."
 end

 test "Mentions" do
   {:ok, serverPid} = GenServer.start(Twitter, %{})

   {response, data} = GenServer.call(serverPid, {:RegisterUser, "abc", "123"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:RegisterUser, "abc", "123"})
   assert ret == :ok
   assert reason == "success"

   {response, data} = GenServer.call(serverPid, {:RegisterUser, "pqr", "112"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:RegisterUser, "pqr", "112"})
   assert ret == :ok
   assert reason == "success"

   {response, data} = GenServer.call(serverPid, {:RegisterUser, "xyz", "421"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:RegisterUser, "xyz", "421"})
   assert ret == :ok
   assert reason == "success"

   {response, data} = GenServer.call(serverPid, {:TweetPost, "abc", "123", "first tweet"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:TweetPost, "abc", "123", "first tweet #awesome"})
   assert ret == :ok
   assert reason == "success"

   {response, data} = GenServer.call(serverPid, {:TweetPost, "xyz", "421", "i love #coffee #awesome @abc"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:TweetPost, "xyz", "421", "i love #coffee #awesome @abc"})
   assert ret == :ok
   assert reason == "success"

   {response, data} = GenServer.call(serverPid, {:Mention, "abc", "123"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:Mention, "abc", "123"})
   assert ret == :ok
   assert Enum.count(reason) == 1
   [{posted_by_2, _b, tweet_2}] = reason
   assert posted_by_2 == "xyz"
   assert tweet_2 == "i love #coffee #awesome @abc"


   {response, data} = GenServer.call(serverPid, {:TweetPost, "pqr", "112", "greetings @abc"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:TweetPost, "pqr", "112", "greetings @abc"})
   #IO.inspect(reason)
   assert ret == :ok
   assert reason == "success"

   {response, data} = GenServer.call(serverPid, {:Mention, "abc", "123"})
   assert response==:redirect
   {ret, reason} = GenServer.call(data, {:Mention, "abc", "123"})
   assert ret == :ok
   assert Enum.count(reason) == 2
   [{posted_by_2, _b, tweet_2}, {posted_by_3, _a, tweet_3}] = reason
   assert posted_by_2 == "xyz"
   assert tweet_2 == "i love #coffee #awesome @abc"
   assert posted_by_3 == "pqr"
   assert tweet_3 == "greetings @abc"
 end




end
