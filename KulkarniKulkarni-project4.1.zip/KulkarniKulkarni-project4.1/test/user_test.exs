defmodule UserServerTest do
  use ExUnit.Case
  doctest UserServer

  test "createuser" do
    {:ok, serverPid}= GenServer.start(UserServer, %{})
    newuser = %UserData{userid: "", password: "123"}
    {ret, _reason} = GenServer.call(serverPid, {:register_user, newuser})
    assert ret == :ok


    newuser = %UserData{userid: "ab", password: ""}
    {ret, _reason}= GenServer.call(serverPid, {:register_user, newuser})
    assert ret == :ok


    newuser = %UserData{userid: "abc", password: "123"}
    {ret,reason}= GenServer.call(serverPid, {:register_user, newuser})
    assert ret == :ok
    assert reason == "success"

    {ret, reason} = GenServer.call(serverPid, {:register_user, newuser})
    assert ret == :bad
    assert reason == "already exists"

  end

  test "delete_user" do
    {:ok, serverPid} = GenServer.start(UserServer, %{})
    {ret, reason} = GenServer.call(serverPid, {:delete_user, "ab"} )
    assert ret == :bad
    assert reason == "invalid id";


    newuser = %UserData{userid: "Abc" , password: "123"}
    {ret, reason} = GenServer.call(serverPid, {:register_user, newuser})
    assert ret == :ok
    assert reason == "success"

    {ret, reason} = GenServer.call(serverPid, {:delete_user, "abc"})
    assert ret == :bad
    assert reason == "invalid id"

    {ret, reason} = GenServer.call(serverPid, {:delete_user, "Abc"})
    assert ret == :ok
    assert reason == "success"

    {ret, reason} = GenServer.call(serverPid, {:register_user, newuser})
    assert ret == :ok
    assert reason == "success"
  end
end
